#include "resultat.h"
#include <QQmlEngine>
#include "DataApi/dataResultats.h"
#include <QDateTime>

Resultat::Resultat(QObject *parent) : QObject(parent)
{

}

Resultat::Resultat(QJsonObject dataJson, QObject *parent) : QObject(parent)
{
    // Parse QDateTime from JSON object
    date = QDateTime::fromString(dataJson["date"].toString(), "yyyy-MM-dd HH:mm:ss");
    idPartie = dataJson["idPartie"].toString().toInt();
    tempsReaction = dataJson["tempsReactionJ1"].toString().toInt();
    plotsAppuyes = dataJson["plotsAppuyes"].toString().toInt();
    plotsTotaux = dataJson["plotsTotaux"].toString().toInt();
    identifiant = dataJson["identifiant"].toString();
}

QString Resultat::toString()
{
    QString result = "";
    result += "Date : " + date.toString("yyyy-MM-dd HH:mm:ss") + "\n";
    result += "idPartie : " + QString::number(idPartie) + "\n";
    result += "Temps de réaction Joueur : " + QString::number(tempsReaction) + "\n";
    result += "Plots appuyes : " + QString::number(plotsAppuyes) + "\n";
    result += "Plots totaux : " + QString::number(plotsTotaux) + "\n";
    result += "Identifiant : " + identifiant + "\n";

    return result;
}
