#ifndef STATISTIQUES_H
#define STATISTIQUES_H

#include <QObject>
#include <QDate>
#include <QJsonObject>
#include "joueur.h"
#include "DataApi/dataResultats.h"

class Resultat : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QString date READ getDate NOTIFY dateChanged)
    Q_PROPERTY(int tempsReaction READ getTempsReaction NOTIFY tempsReactionChanged)
    Q_PROPERTY(int plotAppuyes READ getPlotsAppuyes NOTIFY plotAppuyesChanged)
    Q_PROPERTY(int plotsTotaux READ getPlotsTotaux NOTIFY plotsTotauxChanged)
    Q_PROPERTY(QString identifiant READ getIdentifiant NOTIFY identifiantChanged)

public:
    Resultat(QObject *parent = nullptr);
    Resultat(QJsonObject dataJson, QObject *parent = nullptr);

    QString toString();

    QString getDate() const { return date.toString("yyyy-MM-ddTHH:mm:ss"); }
    void setDate(const QDateTime &date) { this->date = date; }

    int getPlotsAppuyes() const { return plotsAppuyes; }
    void setPlotsAppuyes(int plotsAppuyes) { this->plotsAppuyes = plotsAppuyes; }

    int getTempsReaction() const { return tempsReaction; }
    void setTempsReaction(int tempsReaction) { this->tempsReaction = tempsReaction; }

    QString getIdentifiant() const { return identifiant; }
    void setIdentifiant(const QString &identifiant) { this->identifiant = identifiant; }

    int getPlotsTotaux() const { return plotsTotaux; }
    void setPlotsTotaux(int plotsTotaux) { this->plotsTotaux = plotsTotaux; }

signals:
    void dateChanged();
    void tempsReactionChanged();
    void plotAppuyesChanged();
    void identifiantChanged();
    void plotsTotauxChanged();

private:
    int idPartie;
    QDateTime date;
    int tempsReaction;
    int plotsAppuyes;
    QString identifiant;
    int plotsTotaux;
};

#endif // STATISTIQUES_H
