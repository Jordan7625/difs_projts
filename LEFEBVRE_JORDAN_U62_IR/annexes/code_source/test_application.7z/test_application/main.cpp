#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QtSql>
#include <QApplication>
#include <QDebug>
#include <QQmlContext>
#include <QDebug>
#include "entites/resultat.h"
#include "controller.h"
#include "DataApi/dataJoueurs.h"





int main(int argc, char *argv[])
{

#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif



    DataJoueurs dataJoueurs;


    DataResultats dataResultats;


    Controller controller(&dataJoueurs,&dataResultats);



    //dataJoueurs.getJoueurs();

    //dataJoueurs.getStatistiques();

    //dataJoueurs.getDate();


    //dataJoueurs.getJoueur("2");

    //dataJoueurs.createJoueur("identifiant", "password", "email");


    //dataJoueurs.getTours();


   // dataJoueurs.getUnepartie("1");








    QApplication app(argc, argv);
    QQmlApplicationEngine engine;


    // partager au QML le Joueur
    qmlRegisterType<Joueur>("Joueur", 1, 0, "Joueur");
    //partager au QML le resultat
    qmlRegisterType<Resultat>("EntiteResultat", 1, 0, "Resultat");
    //partager au QML le controller
    engine.rootContext()->setContextProperty("controller", &controller);

    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);




    return app.exec();
}
