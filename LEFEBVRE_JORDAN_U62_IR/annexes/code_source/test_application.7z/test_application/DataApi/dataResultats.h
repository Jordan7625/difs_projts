#ifndef DATARESULTATS_H
#define DATARESULTATS_H

#include <QObject>
#include <QNetworkAccessManager>
#include "entites/resultat.h"
#include <QJsonDocument>

class DataResultats : public QObject
{
    Q_OBJECT



public:


    DataResultats(QObject *parent=nullptr);

    void getStatistiques();

    void getStatistiquesUnjoueur(const QString &identifiant);

    void getUnepartie(const QString &id);

    void createPartie(const QString &date, const int tempsReactionJ1, const int tempsReactionJ2, const int joueur1_id, const int joueur2_id);

    void createConfig(const QString couleurPlot, int nbJoueur, int nbPlots, int tempsPourAppuyer, int nbPlotsAppuyes);


signals:

    void creationPartieReussie();
    void creationPartieEchouee();

    void creationConfigReussie();
    void creationConfigEchouee();

    void statistiquesChanger(QJsonDocument jsonData);


private slots:

    void lireDataGetStatistiques(QNetworkReply *reply);

    void lireDataGetPartie(QNetworkReply *reply);

    void lireDataCreatePartie(QNetworkReply *reply);

    void lireDataCreateConfig(QNetworkReply *reply);

    void lireStatistiquesUnJoueur(QNetworkReply *reply);


private:
    QNetworkAccessManager *manager;





};

#endif // DATARESULTATS_H

