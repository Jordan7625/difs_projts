#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <QObject>
#include "DataApi/dataJoueurs.h"
#include "DataApi/dataResultats.h"
#include <QQmlListProperty>

class Controller : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QQmlListProperty<Resultat> listeResultats READ getListeMonnaies NOTIFY listeResultatsChanged)

public:


    explicit Controller(DataJoueurs* dataJoueurs, DataResultats* dataResultats, QObject *parent = nullptr);
    Q_INVOKABLE void createJoueur(const QString &identifiant, const QString &password, const QString &email);
    Q_INVOKABLE void connexionJoueur(const QString &identifiant, const QString &password);
    Q_INVOKABLE void createConfig(const QString couleurPlot, const int nbJoueur, int nbPlots, const int tempsPourAppuyer, const int nbPlotsAppuyes);
    void identifiantExiste(const QString &identifiant);

    Q_INVOKABLE void getStatistiques();

    Q_INVOKABLE void getStatistiquesUnjoueur();

    void getUnepartie(const QString &identifiant);

    Q_INVOKABLE bool testerJoueurConnecte();

    QQmlListProperty<Resultat> getListeMonnaies(){return QQmlListProperty<Resultat>(this, &listeResultats);}





signals:
    void creationJoueurReussie();
    void creationJoueurEchoue();
    void connexionJoueurReussie();
    void connexionJoueurEchoue();
    void statistiquesChanger();

    void creationConfigReussie();
    void creationConfigEchouee();

    void listeResultatsChanged();

public slots:
    void lireCreateJoueurReussie();
    void lireCreateJoueurEchoue();
    void lireCreateConfigReussie();
    void lireCreateConfigEchouee();
    void lireConnexionJoueurReussie(QJsonObject jsonJoueur);
    void lireConnexionJoueurEchoue();
    void lireStatistiques();
    void lireStatistiquesUnJoueur();

    void afficherStatistiques(QJsonDocument jsonData);
    void afficherStatistiquesUnJoueur(QJsonDocument jsonData);
private:
    DataJoueurs* dataJoueurs;
    Joueur* joueurConnecte;
    DataResultats* dataResultats;
    QList<Resultat*> listeResultats;
};

#endif // CONTROLLER_H
